const $=id=>document.getElementById(id);
const screens={home:$('home'),question:$('question'),result:$('result')};
const EXAM_LEN=20;
let mode='home',level='easy',current=null,trainGood=0,trainTotal=0,exam=[],examIndex=0,examGood=0;
function isPractice(){return mode==='simulation'}
function practiceLevel(){return 'easy'}


const NL={
  width:2100,
  // Рабочая область логарифмических шкал 1 и 2 на исходной текстуре.
  // 1..1000 занимают три одинаковые логарифмические декады.
  x0:160,
  x1:1918,
  shift:0,
  visor:1045,
  side:1,
  minShift:-560,
  maxShift:560
};

function rnd(a,b,step=1){const n=Math.floor((b-a)/step)+1;return a+Math.floor(Math.random()*n)*step}
function pick(a){return a[Math.floor(Math.random()*a.length)]}
function round(v,d=1){const p=10**d;return Math.round(v*p)/p}
function fmt(v,unit=''){return `${Number.isInteger(v)?v:round(v,1)}${unit?' '+unit:''}`}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function show(name){Object.values(screens).forEach(s=>s.classList.add('hidden'));screens[name].classList.remove('hidden');$('scoreBox').classList.toggle('hidden',name==='home'||name==='result');if(name==='home')mode='home'}
function rows(data){return data.map(([a,b])=>`<div class="row"><span>${a}</span><b>${b}</b></div>`).join('')}
function inputs(labels){$('answers').innerHTML=`<div class="answergrid">${labels.map((l,i)=>`<div class="af"><label>${l}</label><input id="ans${i}" type="number" inputmode="decimal" step="any" autocomplete="off"></div>`).join('')}</div>`}

function scaleX(v){
  v=Math.abs(Number(v));
  if(!Number.isFinite(v)||v<=0)return NL.x0;
  return NL.x0+(Math.log10(v)/3)*(NL.x1-NL.x0);
}
function scaleValue(x){
  const p=(x-NL.x0)/(NL.x1-NL.x0);
  return 10**(3*p);
}
function shiftFor(fixedValue,movingValue){return scaleX(fixedValue)-scaleX(movingValue)}
function niceScale(v){
  if(!Number.isFinite(v)||v<=0)return '—';
  if(v>=100)return String(round(v,0));
  if(v>=10)return String(round(v,1));
  return String(round(v,2));
}

function makeSVT(solve){
  const v=pick([180,210,240,270,300,320,360,400,420,450,480,540,600,720]);
  const t=pick([10,12,15,18,20,24,25,30,36,40,45,50]);
  const s=round(v*t/60,1);
  const common={type:'Скорость · время · расстояние',tol:.25,visual:{kind:'svt',v,t,s,solve}};
  if(solve==='distance')return {...common,title:'Определите пройденное расстояние',data:[['Путевая скорость',fmt(v,'км/ч')],['Время',fmt(t,'мин')]],labels:['Расстояние, км'],answers:[s],explain:`Установите индекс 60 шкалы времени против ${v} км/ч. Под ${t} мин по шкале времени считывается ${s} км. Проверка: S = V·t/60 = ${s} км.`};
  if(solve==='time')return {...common,title:'Определите время полёта',data:[['Расстояние',fmt(s,'км')],['Путевая скорость',fmt(v,'км/ч')]],labels:['Время, мин'],answers:[t],explain:`Установите 60 против ${v}. На ${s} км по верхней шкале по шкале времени считывается ${t} мин. Проверка: t = 60S/V = ${t} мин.`};
  return {...common,title:'Определите путевую скорость',data:[['Расстояние',fmt(s,'км')],['Время',fmt(t,'мин')]],labels:['Скорость, км/ч'],answers:[v],explain:`Совместите ${t} мин шкалы времени с ${s} км. Против индекса 60 считывается ${v} км/ч. Проверка: V = 60S/t = ${v} км/ч.`};
}
function makeConversion(){
  const kmh=pick([108,144,180,216,252,288,324,360,432,540,720]),ms=round(kmh/3.6,1);
  if(Math.random()<.5)return {type:'Индекс 36',title:'Переведите скорость из км/ч в м/с',data:[['Скорость',fmt(kmh,'км/ч')]],labels:['Скорость, м/с'],answers:[ms],tol:.15,explain:`Индекс 36 используется для перехода км/ч ↔ м/с. Проверка: ${kmh}/3,6 = ${ms} м/с.`,visual:{kind:'conversion',kmh,ms,from:'kmh'}};
  return {type:'Индекс 36',title:'Переведите скорость из м/с в км/ч',data:[['Скорость',fmt(ms,'м/с')]],labels:['Скорость, км/ч'],answers:[kmh],tol:.2,explain:`Индекс 36 используется для перехода км/ч ↔ м/с. Проверка: ${ms}·3,6 = ${kmh} км/ч.`,visual:{kind:'conversion',kmh,ms,from:'ms'}};
}
function makeRatio(){
  const a=pick([1.2,1.5,1.8,2,2.4,2.5,3,4,5,6,7.5,8]),b=pick([12,15,18,20,24,25,30,36,40,45,50,60]),ans=round(a*b,1);
  return {type:'Умножение',title:'Выполните умножение с помощью НЛ-10М',data:[['Первый множитель',a],['Второй множитель',b]],labels:['Результат'],answers:[ans],tol:.15,explain:`Совместите 10 шкалы 2 с ${a*10} шкалы 1 (эквивалентно 1 с ${a} с учётом порядка). Против ${b} на движке считывается ${ans}.`,visual:{kind:'multiply',a,b,ans}};
}
function makeReadout(){
  const q=makeSVT(pick(['distance','speed','time']));
  q.type='Считывание НЛ-10М';
  q.readout=true;
  q.title=q.visual.solve==='distance'?'Считайте расстояние с уже выставленной НЛ':q.visual.solve==='speed'?'Считайте путевую скорость с уже выставленной НЛ':'Считайте время с уже выставленной НЛ';
  return q;
}
function makeQuestion(l){
  let pool;
  if(l==='easy')pool=[makeSVT('distance'),makeSVT('time'),makeSVT('speed'),makeReadout()];
  else if(l==='medium')pool=[makeSVT('distance'),makeSVT('time'),makeSVT('speed'),makeConversion(),makeRatio(),makeReadout()];
  else if(l==='hard')pool=[makeSVT('distance'),makeSVT('time'),makeSVT('speed'),makeConversion(),makeRatio(),makeReadout(),makeReadout()];
  else pool=[makeSVT('distance'),makeSVT('time'),makeSVT('speed'),makeConversion(),makeRatio()];
  return pick(pool);
}

function taskSetup(q){
  const v=q.visual;
  if(!v)return {shift:0,visor:NL.width/2,hint:''};
  if(v.kind==='svt'){
    if(q.readout){
      if(v.solve==='distance')return {shift:shiftFor(v.v,60),visor:scaleX(v.s),hint:'Линейка уже выставлена. По визирке считайте искомое значение.'};
      if(v.solve==='time')return {shift:shiftFor(v.v,60),visor:scaleX(v.s),hint:'Линейка уже выставлена. По визирке считайте время на движке.'};
      return {shift:shiftFor(v.s,v.t),visor:scaleX(v.v),hint:'Линейка уже выставлена. По индексу 60 считайте скорость.'};
    }
    if(v.solve==='distance')return {shift:0,visor:scaleX(60),hint:`Перетащите движок: совместите 60 на шкале времени с ${v.v} км/ч. Затем поставьте визирку на ${v.t} мин и считайте расстояние по верхней шкале.`};
    if(v.solve==='time')return {shift:0,visor:scaleX(v.s),hint:`Совместите 60 на движке с ${v.v} км/ч. Поставьте визирку на ${v.s} км и считайте время на движке.`};
    return {shift:0,visor:scaleX(60),hint:`Совместите ${v.t} мин на движке с ${v.s} км. Затем по индексу 60 считайте скорость.`};
  }
  if(v.kind==='conversion')return {shift:0,visor:scaleX(v.kmh),hint:'Для перевода км/ч ↔ м/с используйте красный индекс 36 на движке. Перемещайте движок и визирку вручную.'};
  if(v.kind==='multiply')return {shift:0,visor:scaleX(v.ans),hint:'Для умножения совместите базовый индекс одной шкалы с первым множителем и считайте результат против второго множителя.'};
  return {shift:0,visor:NL.width/2,hint:''};
}

function buildRuler(){
  $('ruler').innerHTML=`<div class="nl-device">
    <div class="nl-scroll" id="nlScroll" aria-label="Интерактивная навигационная линейка НЛ-10М">
      <div class="nl-stage" id="nlStage">
        <div class="nl-layer nl-top"></div>
        <div class="nl-layer nl-slider" id="nlSlider" title="Перетащите движок"></div>
        <div class="nl-layer nl-bottom"></div>
        <div class="visor" id="nlVisor" title="Перетащите визирку"><div class="visor-glass"></div><div class="visor-line"></div></div>
      </div>
    </div>
    <div class="drag-note"><span><b>Движок:</b> тяните среднюю часть линейки</span><span><b>Визирка:</b> тяните прозрачную рамку</span></div>
    <div class="nl-caption">Изображение и расположение шкал взяты из настольного эмулятора НЛ-10М. На узком экране линейка прокручивается горизонтально.</div>
  </div>`;
  wireRuler();
}
function applyRuler(){
  const stage=$('nlStage'),slider=$('nlSlider'),visor=$('nlVisor');if(!stage||!slider||!visor)return;
  stage.classList.toggle('side2',NL.side===2);
  slider.style.transform=`translateX(${NL.shift}px)`;
  visor.style.left=`${NL.visor}px`;
  $('sideLabel').textContent=NL.side===1?'Сторона 1 · расстояние / скорость / время':'Сторона 2 · высота / скорость / температура';
  updateReadouts();
}
function updateReadouts(){}
function wireDrag(el,kind){
  let active=false,startX=0,startVal=0;
  el.addEventListener('pointerdown',e=>{active=true;startX=e.clientX;startVal=kind==='slider'?NL.shift:NL.visor;el.setPointerCapture?.(e.pointerId);e.preventDefault()});
  el.addEventListener('pointermove',e=>{if(!active)return;const dx=e.clientX-startX;if(kind==='slider')NL.shift=clamp(startVal+dx,NL.minShift,NL.maxShift);else NL.visor=clamp(startVal+dx,35,NL.width-35);applyRuler();e.preventDefault()});
  const stop=()=>active=false;el.addEventListener('pointerup',stop);el.addEventListener('pointercancel',stop);
}
function wireRuler(){wireDrag($('nlSlider'),'slider');wireDrag($('nlVisor'),'visor');applyRuler()}
function resetRuler(){NL.shift=0;NL.visor=NL.width/2;applyRuler();const sc=$('nlScroll');if(sc)sc.scrollLeft=Math.max(0,NL.visor-sc.clientWidth/2)}
function flipRuler(){NL.side=NL.side===1?2:1;applyRuler()}

function drawRuler(q){
  buildRuler();
  NL.side=1;
  const setup=taskSetup(q);NL.shift=setup.shift;NL.visor=setup.visor;applyRuler();
  $('rulerHint').textContent=mode==='simulation'?setup.hint:'';
  requestAnimationFrame(()=>{const sc=$('nlScroll');if(sc)sc.scrollLeft=Math.max(0,NL.visor-sc.clientWidth/2)});
}

function render(q){
  current=q;
  $('type').textContent=q.type;
  const examTitle = mode==='exam' ? `Определите: ${q.labels.join(', ')}` : q.title;
  $('qtitle').textContent=examTitle;
  $('qdata').innerHTML=rows(q.data);
  inputs(q.labels);
  $('feedback').className='feedback hidden';
  $('next').classList.add('hidden');
  $('check').classList.toggle('hidden',mode==='exam');
  $('submitExam').classList.toggle('hidden',mode!=='exam');
  const out=$('trainingOutput');
  if(mode==='simulation'){
    out.classList.remove('hidden');
    out.innerHTML=`<span>Учебное контрольное значение</span><b>${q.labels.map((l,i)=>`${l}: ${q.answers[i]}`).join(' · ')}</b>`;
  }else{
    out.classList.add('hidden');
    out.innerHTML='';
  }
  const hasRuler=level!=='theory'&&q.visual;
  $('rulerCol').classList.toggle('hidden',!hasRuler);
  $('qlayout').classList.toggle('no-ruler',!hasRuler);
  if(hasRuler)drawRuler(q);
  setTimeout(()=>$('ans0')?.focus(),0);
}
function readAnswers(){return current.answers.map((_,i)=>{const e=$('ans'+i);if(!e||e.value.trim()==='')return null;const v=Number(String(e.value).replace(',','.'));return Number.isFinite(v)?v:NaN})}
function valid(a){if(a.some(v=>v===null||Number.isNaN(v))){$('feedback').className='feedback bad';$('feedback').innerHTML='<b>Заполните все поля числовыми значениями.</b>';return false}return true}
function correct(a){return a.every((v,i)=>Math.abs(v-current.answers[i])<=current.tol)}
function startSimulation(){mode='simulation';level=practiceLevel();trainGood=0;trainTotal=0;$('modeBadge').textContent='Симуляция';$('score').textContent='0 / 0';show('question');$('progress').textContent='Свободная практика';render(makeQuestion(level))}
function checkTraining(){const a=readAnswers();if(!valid(a))return;trainTotal++;const ok=correct(a);if(ok)trainGood++;$('score').textContent=`${trainGood} / ${trainTotal}`;$('feedback').className=`feedback ${ok?'ok':'bad'}`;$('feedback').innerHTML=ok?`<b>Верно.</b><br>${current.explain}`:`<b>Неверно.</b><br>Правильный ответ: ${current.answers.join(' · ')}.<br>${current.explain}`;$('check').classList.add('hidden');$('next').classList.remove('hidden')}
function startExam(){mode='exam';level='medium';examIndex=0;examGood=0;const plan=['easy','medium','medium','hard','easy','medium','hard','medium','easy','hard','medium','easy','hard','medium','easy','hard','medium','easy','hard','medium'];exam=plan.map(makeQuestion);$('modeBadge').textContent='Зачёт';show('question');showExam()}
function showExam(){$('progress').textContent=`Задание ${examIndex+1} из ${EXAM_LEN}`;$('score').textContent=`${examIndex} / ${EXAM_LEN}`;render(exam[examIndex])}
function answerExam(){const a=readAnswers();if(!valid(a))return;if(correct(a))examGood++;examIndex++;if(examIndex>=EXAM_LEN)finishExam();else showExam()}
function finishExam(){const p=Math.round(examGood/EXAM_LEN*100);$('resScore').textContent=`${examGood}/${EXAM_LEN}`;$('resPct').textContent=p+'%';$('resGood').textContent=examGood;$('resBad').textContent=EXAM_LEN-examGood;show('result')}

$('simulationBtn').onclick=startSimulation;
$('examBtn').onclick=startExam;
$('check').onclick=checkTraining;
$('next').onclick=()=>{level=practiceLevel();render(makeQuestion(level))};
$('submitExam').onclick=answerExam;
['backHome2','backHome3'].forEach(id=>$(id).onclick=()=>show('home'));
$('again').onclick=startExam;
$('flipSide').onclick=flipRuler;
$('centerRuler').onclick=resetRuler;
document.addEventListener('keydown',e=>{if(e.key!=='Enter'||screens.question.classList.contains('hidden'))return;if(isPractice()){if(!$('check').classList.contains('hidden'))checkTraining();else{level=practiceLevel();render(makeQuestion(level))}}else if(mode==='exam')answerExam()});
window.addEventListener('DOMContentLoaded',()=>{const open=new URLSearchParams(location.search).get('open');if(open==='simulation'||open==='visible'||open==='hidden'||open==='training')$('simulationBtn').click();if(open==='exam')$('examBtn').click()});
