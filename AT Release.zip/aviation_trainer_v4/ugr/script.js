const $=id=>document.getElementById(id);
const screens={home:$('homeScreen'),question:$('questionScreen'),result:$('examResultScreen')};
let mode='home',level='easy',current=null,trainGood=0,trainTotal=0,exam=[],examIndex=0,examGood=0;
const EXAM_LEN=20;
function isPractice(){return mode==='practice-visible'||mode==='practice-hidden'}
function practiceLevel(){return mode==='practice-visible'?'easy':(Math.random()<.45?'medium':'hard')}


function n360(v){return((v%360)+360)%360}
function fmt(v){return String(n360(v)).padStart(3,'0')+'°'}
function ra(step=5){return Math.floor(Math.random()*(360/step))*step}

// Модель отсчётов УГР-4УК.
// ВАЖНО: величина определяется не «стрелкой вообще», а комбинацией
//   элемент + конец + шкала.
//
// Внутренняя шкала — подвижная курсовая:
//   верхний индекс                     -> МК
//   острый конец стрелки АРК           -> МПР
//   тупой/обратный конец стрелки АРК   -> МПС (для вертолёта: МПВ)
//   острый конец курсозадатчика        -> ЗК
//   обратный конец курсозадатчика      -> обратный ЗК = ЗК + 180°
//
// Наружная шкала — неподвижная, отсчитывает угол относительно продольной оси ВС:
//   острый конец стрелки АРК           -> КУР
//   тупой конец стрелки АРК            -> обратный КУР = КУР + 180°
//   острый конец курсозадатчика        -> относительный угол ЗК к текущему МК
//   обратный конец курсозадатчика      -> тот же угол + 180°
const NAV={
  mpr:(mk,kur)=>n360(mk+kur),
  kur:(mk,mpr)=>n360(mpr-mk),
  mk:(mpr,kur)=>n360(mpr-kur),
  mps:mpr=>n360(mpr+180),
  mprFromMps:mps=>n360(mps+180),
  reciprocal:v=>n360(v+180),
  selectedCourseRelative:(mk,zk)=>n360(zk-mk)
};

// Единая таблица реальных отсчётов. Все задания на считывание берут ответы отсюда.
function readings(s){
  const zkRel=NAV.selectedCourseRelative(s.mk,s.zk);
  return {
    mk:s.mk,
    arkSharpOuter:s.kur,                  // КУР
    arkBluntOuter:NAV.reciprocal(s.kur), // обратный КУР
    arkSharpInner:s.mpr,                  // МПР
    arkBluntInner:s.mps,                  // МПС / МПВ
    bugSharpInner:s.zk,                   // ЗК
    bugBluntInner:NAV.reciprocal(s.zk),  // обратный ЗК
    bugSharpOuter:zkRel,
    bugBluntOuter:NAV.reciprocal(zkRel)
  };
}

function state(){
  // Сначала задаём физическое состояние: текущий МК и абсолютное направление
  // на радиостанцию (МПР). КУР и обратный пеленг получаются только из них.
  const mk=ra();
  const mpr=ra();
  const kur=NAV.kur(mk,mpr);
  const mps=NAV.mps(mpr);
  const zk=ra(10);
  return{mk,kur,mpr,mps,zk};
}

function show(name){
  Object.values(screens).forEach(x=>x.classList.add('hidden'));
  screens[name].classList.remove('hidden');
  $('scoreBox').classList.toggle('hidden',name==='home'||name==='result');
  if(name==='home')mode='home';
}

function rows(a){
  return a.length
    ? a.map(([k,v])=>`<div class="data-row"><span>${k}</span><strong>${v}</strong></div>`).join('')
    : `<div class="data-row"><span>Исходные данные</span><strong>Снимите показания с прибора</strong></div>`;
}

function inputs(labels){
  $('answerArea').innerHTML=`<div class="answer-grid">${
    labels.map((l,i)=>`<div class="answer-field"><label>${l}, °</label><input id="ans${i}" type="number" min="0" max="359" inputmode="numeric" placeholder="0–359"></div>`).join('')
  }</div>`;
}

function calcQuestions(s,complex=false){
  const base=[
    {type:'Расчёт',title:'Вычислите МПР',data:[['МК',fmt(s.mk)],['КУР',fmt(s.kur)]],labels:['МПР'],answers:[NAV.mpr(s.mk,s.kur)],ex:`МПР = МК + КУР = ${fmt(s.mpr)} (с приведением к 0–359°).`},
    {type:'Расчёт',title:'Вычислите КУР',data:[['МК',fmt(s.mk)],['МПР',fmt(s.mpr)]],labels:['КУР'],answers:[NAV.kur(s.mk,s.mpr)],ex:`КУР = МПР − МК = ${fmt(s.kur)} (с приведением к 0–359°).`},
    {type:'Расчёт',title:'Вычислите МК',data:[['КУР',fmt(s.kur)],['МПР',fmt(s.mpr)]],labels:['МК'],answers:[NAV.mk(s.mpr,s.kur)],ex:`МК = МПР − КУР = ${fmt(s.mk)} (с приведением к 0–359°).`},
    {type:'Расчёт',title:'Вычислите МПС',data:[['МПР',fmt(s.mpr)]],labels:['МПС'],answers:[NAV.mps(s.mpr)],ex:`МПС — обратный пеленг: МПС = МПР ± 180° = ${fmt(s.mps)}.`},
    {type:'Расчёт',title:'Вычислите МПР по МПС',data:[['МПС',fmt(s.mps)]],labels:['МПР'],answers:[NAV.mprFromMps(s.mps)],ex:`МПР и МПС противоположны: МПР = МПС ± 180° = ${fmt(s.mpr)}.`}
  ];
  if(complex){
    base.push(
      {type:'Комплекс',title:'Определите КУР и МПС',data:[['МК',fmt(s.mk)],['МПР',fmt(s.mpr)]],labels:['КУР','МПС'],answers:[s.kur,s.mps],ex:`КУР = МПР − МК = ${fmt(s.kur)}; МПС = МПР ± 180° = ${fmt(s.mps)}.`},
      {type:'Комплекс',title:'По МК и МПС определите КУР',data:[['МК',fmt(s.mk)],['МПС',fmt(s.mps)]],labels:['КУР'],answers:[s.kur],ex:`Сначала МПР = МПС ± 180° = ${fmt(s.mpr)}, затем КУР = МПР − МК = ${fmt(s.kur)}.`}
    );
  }
  return base;
}

function readingQuestions(s,hard=false,includeAllReadings=true){
  const r=readings(s);
  const q=[
    {type:'Считывание',title:'Определите магнитный курс по прибору',data:[],labels:['МК'],answers:[r.mk],ex:`МК считывается по внутренней подвижной шкале против верхнего неподвижного индекса: ${fmt(r.mk)}.`},
    {type:'Считывание',title:'Считайте КУР острым концом стрелки АРК',data:[],labels:['КУР'],answers:[r.arkSharpOuter],ex:`Острый конец стрелки АРК + наружная неподвижная шкала = КУР: ${fmt(r.arkSharpOuter)}.`},
    {type:'Считывание',title:'Считайте МПР острым концом стрелки АРК',data:[],labels:['МПР'],answers:[r.arkSharpInner],ex:`Острый конец стрелки АРК + внутренняя подвижная шкала = МПР: ${fmt(r.arkSharpInner)}.`},
    {type:'Считывание',title:'Считайте МПС тупым концом стрелки АРК',data:[],labels:['МПС'],answers:[r.arkBluntInner],ex:`Тупой (обратный) конец стрелки АРК + внутренняя подвижная шкала = МПС (для вертолёта — МПВ): ${fmt(r.arkBluntInner)}.`},
    {type:'Считывание',title:'Что показывает тупой конец стрелки АРК по наружной шкале?',data:[],labels:['Обратный КУР'],answers:[r.arkBluntOuter],ex:`На наружной шкале тупой конец не является МПС. Это обратное направление стрелки: КУР + 180° = ${fmt(r.arkBluntOuter)}.`}
  ];
  if(hard){
    q.push(
      {type:'Считывание',title:'Определите заданный курс по острому концу курсозадатчика',data:[],labels:['ЗК'],answers:[r.bugSharpInner],ex:`Острый конец курсозадатчика + внутренняя подвижная шкала = ЗК: ${fmt(r.bugSharpInner)}.`},
      {type:'Считывание',title:'Определите значение обратного конца курсозадатчика по внутренней шкале',data:[],labels:['ЗК + 180°'],answers:[r.bugBluntInner],ex:`Обратный конец курсозадатчика по внутренней шкале расположен на 180° от ЗК: ${fmt(r.bugBluntInner)}.`}
    );
    if(includeAllReadings){
      q.push({type:'Комплекс',title:'Снимите основные показания УГР-4УК',data:[],labels:['МК','КУР','МПР','МПС','ЗК'],answers:[r.mk,r.arkSharpOuter,r.arkSharpInner,r.arkBluntInner,r.bugSharpInner],ex:`МК ${fmt(r.mk)}; КУР ${fmt(r.arkSharpOuter)}; МПР ${fmt(r.arkSharpInner)}; МПС ${fmt(r.arkBluntInner)}; ЗК ${fmt(r.bugSharpInner)}.`});
    }
  }
  return q;
}

function makeQuestion(l,includeAllReadings=true){
  const s=state();
  let pool;
  if(l==='theory') pool=calcQuestions(s,true);
  else if(l==='easy') pool=[...readingQuestions(s),...calcQuestions(s)];
  else if(l==='medium') pool=[...readingQuestions(s),...calcQuestions(s,true)];
  else pool=[...readingQuestions(s,true),...calcQuestions(s,true),...calcQuestions(s,true)];
  const q=pool[Math.floor(Math.random()*pool.length)];
  return {...q,s,level:l};
}

function readAns(){
  return current.answers.map((_,i)=>{
    const e=$('ans'+i);
    if(!e||e.value.trim()==='')return null;
    const v=Number(e.value);
    return Number.isFinite(v)&&v>=0&&v<=359?n360(v):NaN;
  });
}

function good(a){return a.every((v,i)=>v===n360(current.answers[i]))}

function valid(a){
  if(a.some(v=>v===null||Number.isNaN(v))){
    $('feedback').className='feedback bad';
    $('feedback').innerHTML='<strong>Заполните все поля.</strong><br>Допустимы значения 0–359°.';
    return false;
  }
  return true;
}

function render(q){
  current=q;
  $('questionType').textContent=q.type;
  const examTitle = (mode==='exam' && q.type==='Считывание')
    ? `Определите: ${q.labels.join(', ')}`
    : q.title;
  $('questionTitle').textContent=examTitle;
  $('questionData').innerHTML=rows(q.data);
  inputs(q.labels);
  $('feedback').className='feedback hidden';
  $('nextBtn').classList.add('hidden');
  $('checkBtn').classList.toggle('hidden',mode==='exam');
  $('examAnswerBtn').classList.toggle('hidden',mode!=='exam');

  const hasInstrument=q.level!=='theory';
  $('instrumentColumn').classList.toggle('hidden',!hasInstrument);
  $('questionLayout').classList.toggle('no-instrument',!hasInstrument);
  if(hasInstrument) renderInstrument(q.s,mode==='practice-visible');

  setTimeout(()=>$('ans0')?.focus(),0);
}

function startPractice(kind){
  mode=kind==='visible'?'practice-visible':'practice-hidden';
  level=practiceLevel();
  trainGood=0;
  trainTotal=0;
  $('score').textContent='0 / 0';
  $('modeBadge').textContent=kind==='visible'?'С показаниями':'Без показаний';
  $('progressBadge').textContent='Свободная практика';
  show('question');
  render(makeQuestion(level));
}

function checkTrain(){
  const a=readAns();
  if(!valid(a))return;
  trainTotal++;
  const ok=good(a);
  if(ok)trainGood++;
  $('score').textContent=`${trainGood} / ${trainTotal}`;

  if(ok){
    $('feedback').className='feedback ok';
    $('feedback').innerHTML='<strong>Верно.</strong><br>'+current.ex;
  }else{
    const right=current.answers.map((v,i)=>`${current.labels[i]}: ${fmt(v)}`).join(' · ');
    $('feedback').className='feedback bad';
    $('feedback').innerHTML=`<strong>Неверно.</strong><br>Правильный ответ: ${right}<br>${current.ex}`;
  }

  $('checkBtn').classList.add('hidden');
  $('nextBtn').classList.remove('hidden');
}

function startExam(){
  mode='exam';
  examIndex=0;
  examGood=0;
  const plan=['easy','medium','hard','theory','medium','hard','easy','theory','medium','hard','easy','medium','theory','hard','medium','easy','hard','theory','medium','hard'];
  // В зачёте обязательно ровно одно комплексное задание на снятие всех 5 показателей.
  // Все остальные 19 вопросов генерируются с запретом этого типа задания.
  exam=plan.map(l=>makeQuestion(l,false));
  const allIndex=2+Math.floor(Math.random()*(EXAM_LEN-4));
  const s=state();
  const allReadings=readingQuestions(s,true,true).find(q=>q.labels?.length===5);
  exam[allIndex]={...allReadings,s,level:'hard'};
  show('question');
  $('modeBadge').textContent='Зачёт';
  showExam();
}

function showExam(){
  $('progressBadge').textContent=`Задание ${examIndex+1} из ${EXAM_LEN}`;
  $('score').textContent=`${examIndex} / ${EXAM_LEN}`;
  render(exam[examIndex]);
}

function submitExam(){
  const a=readAns();
  if(!valid(a))return;
  if(good(a))examGood++;
  examIndex++;
  if(examIndex>=EXAM_LEN)finishExam();
  else showExam();
}

function finishExam(){
  const p=Math.round(examGood/EXAM_LEN*100);
  $('examResultScore').textContent=`${examGood}/${EXAM_LEN}`;
  $('examResultPercent').textContent=p+'%';
  $('examCorrect').textContent=examGood;
  $('examWrong').textContent=EXAM_LEN-examGood;
  show('result');
}

function svgEl(tag,attrs={}){
  const e=document.createElementNS('http://www.w3.org/2000/svg',tag);
  Object.entries(attrs).forEach(([k,v])=>e.setAttribute(k,v));
  return e;
}

function polar(cx,cy,r,deg){
  const a=(deg-90)*Math.PI/180;
  return [cx+r*Math.cos(a),cy+r*Math.sin(a)];
}

function renderInstrument(s,showValues){
  const c=250;
  const svg=svgEl('svg',{viewBox:'0 0 500 500',class:'ugr-svg','aria-label':'УГР-4УК'});
  const defs=svgEl('defs');
  defs.innerHTML=`
    <radialGradient id="caseG">
      <stop offset="0" stop-color="#2d3132"/>
      <stop offset=".68" stop-color="#111416"/>
      <stop offset="1" stop-color="#020304"/>
    </radialGradient>
    <radialGradient id="glassG">
      <stop offset="0" stop-color="rgba(255,255,255,0.08)"/>
      <stop offset=".55" stop-color="rgba(255,255,255,0.02)"/>
      <stop offset="1" stop-color="rgba(255,255,255,0)"/>
    </radialGradient>
    <linearGradient id="yellowG" x1="0" x2="0" y1="0" y2="1">
      <stop offset="0" stop-color="#ffd25f"/>
      <stop offset="1" stop-color="#dca028"/>
    </linearGradient>
  `;
  svg.appendChild(defs);

  // Корпус
  svg.appendChild(svgEl('rect',{x:18,y:18,width:464,height:464,rx:48,fill:'url(#caseG)',stroke:'#343b3f','stroke-width':8}));
  [[55,55],[445,55],[55,445],[445,445]].forEach(([x,y])=>{
    svg.appendChild(svgEl('circle',{cx:x,cy:y,r:18,fill:'#6a624f',stroke:'#090a0b','stroke-width':5}));
    svg.appendChild(svgEl('line',{x1:x-9,y1:y+2,x2:x+9,y2:y-2,stroke:'#171717','stroke-width':3}));
  });

  // Окно прибора
  svg.appendChild(svgEl('circle',{cx:c,cy:c,r:202,fill:'#0a0d0e',stroke:'#050606','stroke-width':10}));

  // Наружная статичная шкала
  for(let d=0; d<360; d+=5){
    const major=d%30===0;
    const mid=!major&&d%10===0;
    const [x1,y1]=polar(c,c,190,d);
    const [x2,y2]=polar(c,c,major?167:(mid?174:180),d);
    svg.appendChild(svgEl('line',{
      x1,y1,x2,y2,
      stroke:'#e6e0be',
      'stroke-width':major?3.8:(mid?2.2:1.2),
      'stroke-linecap':'round',
      opacity:major?1:(mid?0.95:0.9)
    }));
  }

  // Статичные треугольные указатели 0 / 90 / 180 / 270
  const cardinalMarkers=[
    {deg:0, pts:'250 47 239 72 261 72'},
    {deg:90, pts:'453 250 428 239 428 261'},
    {deg:180, pts:'250 453 239 428 261 428'},
    {deg:270, pts:'47 250 72 239 72 261'}
  ];
  cardinalMarkers.forEach(m=>{
    svg.appendChild(svgEl('polygon',{points:m.pts,fill:'#eee7bd'}));
  });

  // Подписи внешней неподвижной шкалы
  // Числа вынесены дальше от центра, чтобы не накладываться на штрихи диска.
  const outerLabels=[0,30,60,90,120,150,180,210,240,270,300,330];
  outerLabels.forEach(d=>{
    const g=svgEl('g',{transform:`rotate(${d} ${c} ${c})`});
    const t=svgEl('text',{
      x:c,y:c-209,fill:'#b7b292','font-size':12,'font-weight':700,
      'text-anchor':'middle','dominant-baseline':'middle'
    });
    t.textContent=String(d===0?0:d/10);
    g.appendChild(t);
    svg.appendChild(g);
  });

  // Подвижный диск курса
  const card=svgEl('g',{transform:`rotate(${-s.mk} ${c} ${c})`});
  svg.appendChild(card);
  card.appendChild(svgEl('circle',{cx:c,cy:c,r:145,fill:'#121617',stroke:'#343a38','stroke-width':2}));

  // Деления диска
  for(let d=0; d<360; d+=2){
    const major=d%30===0;
    const mid=!major&&d%10===0;
    const [x1,y1]=polar(c,c,166,d);
    const [x2,y2]=polar(c,c,major?143:(mid?149:155),d);
    card.appendChild(svgEl('line',{
      x1,y1,x2,y2,
      stroke:'#f0ebce',
      'stroke-width':major?4:(mid?2.5:1.35),
      'stroke-linecap':'round'
    }));
  }

  // Подписи подвижного диска: С / В / Ю / З и значения через 30°
  const cardLabels=[0,30,60,90,120,150,180,210,240,270,300,330];
  cardLabels.forEach(d=>{
    const g=svgEl('g',{transform:`rotate(${d} ${c} ${c})`});
    const t=svgEl('text',{
      x:c,y:c-126,fill:'#f1eccd','font-size':28,'font-weight':700,
      'text-anchor':'middle','dominant-baseline':'middle'
    });

    if(d===0) t.textContent='С';
    else if(d===90) t.textContent='В';
    else if(d===180) t.textContent='Ю';
    else if(d===270) t.textContent='З';
    else t.textContent=String(d/10);

    g.appendChild(t);
    card.appendChild(g);
  });

  // Стрелка направления АРК — на заднем плане (геометрию/дизайн не меняем)
  const ark=svgEl('g',{transform:`rotate(${s.kur} ${c} ${c})`});
  const arkBody=svgEl('path',{
    d:[
      'M 250 84',
      'L 235 112',
      'L 242 112',
      'L 242 244',
      'L 246 250',
      'L 246 396',
      'L 254 396',
      'L 254 250',
      'L 258 244',
      'L 258 112',
      'L 265 112',
      'Z'
    ].join(' '),
    fill:'#111111',
    stroke:'#f2f2f0',
    'stroke-width':2.2,
    'stroke-linejoin':'round'
  });
  const arkHead=svgEl('polygon',{
    points:'250,76 238,104 262,104',
    fill:'#f0eee8',
    stroke:'#f2f2f0',
    'stroke-width':1.5
  });
  ark.appendChild(arkBody);
  ark.appendChild(arkHead);
  svg.appendChild(ark);

  // Курсозадатчик ЗК — поверх стрелки АРК (геометрию/дизайн не меняем)
  const bugAngle=NAV.selectedCourseRelative(s.mk,s.zk);
  const bug=svgEl('g',{transform:`rotate(${bugAngle} ${c} ${c})`});

  // Передний участок до указателя
  bug.appendChild(svgEl('rect',{x:247.6,y:116,width:4.8,height:134,rx:1.5,fill:'url(#yellowG)'}));
  bug.appendChild(svgEl('polygon',{points:'250,82 241,112 259,112',fill:'url(#yellowG)',stroke:'#8a621a','stroke-width':1.2}));

  // Задний участок после центра — черный
  bug.appendChild(svgEl('rect',{x:248.2,y:250,width:3.6,height:112,rx:1.5,fill:'#0f0f10'}));
  // Хвостовой желтый указатель
  bug.appendChild(svgEl('polygon',{points:'250,394 242,364 258,364',fill:'url(#yellowG)',stroke:'#8a621a','stroke-width':1.1}));

  svg.appendChild(bug);

  // Центральная втулка и небольшой блик
  svg.appendChild(svgEl('circle',{cx:c,cy:c,r:21,fill:'#171b1d',stroke:'#676c66','stroke-width':3}));
  svg.appendChild(svgEl('circle',{cx:c-5,cy:c-5,r:7,fill:'#525957',opacity:.45}));



  $('instrumentMount').innerHTML='';
  $('instrumentMount').appendChild(svg);

  if(showValues){
    $('instrumentValues').innerHTML=`
      <div><span>МК</span><strong>${fmt(s.mk)}</strong></div>
      <div><span>КУР</span><strong>${fmt(s.kur)}</strong></div>
      <div><span>МПР</span><strong>${fmt(s.mpr)}</strong></div>
      <div><span>МПС</span><strong>${fmt(s.mps)}</strong></div>
    `;
    $('instrumentLegend').innerHTML='<b>Стрелка АРК:</b> острый конец — КУР по внешней / МПР по внутренней; тупой — обратный КУР по внешней / МПС по внутренней. <b>Курсозадатчик:</b> ЗК читается по внутренней шкале.';
  }else{
    $('instrumentValues').innerHTML='';
    $('instrumentLegend').innerHTML='';
  }
}

$('visibleModeBtn').onclick=()=>startPractice('visible');
$('hiddenModeBtn').onclick=()=>startPractice('hidden');
$('examModeBtn').onclick=startExam;
$('checkBtn').onclick=checkTrain;
$('nextBtn').onclick=()=>{level=practiceLevel();render(makeQuestion(level))};
$('examAnswerBtn').onclick=submitExam;
$('homeBtn').onclick=()=>show('home');
$('resultHomeBtn').onclick=()=>show('home');
$('restartExamBtn').onclick=startExam;

document.addEventListener('keydown',e=>{
  if(e.key!=='Enter'||screens.question.classList.contains('hidden'))return;
  if(isPractice()){
    if(!$('checkBtn').classList.contains('hidden'))checkTrain();
    else{level=practiceLevel();render(makeQuestion(level))}
  }else if(mode==='exam'){
    submitExam();
  }
});

window.addEventListener('DOMContentLoaded',()=>{
  const p=new URLSearchParams(location.search);
  const open=p.get('open');
  if(open==='visible'||open==='training') $('visibleModeBtn')?.click();
  if(open==='hidden') $('hiddenModeBtn')?.click();
  if(open==='exam') $('examModeBtn')?.click();
});
